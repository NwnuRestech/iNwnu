package com.xxs.service;

public class StuIndentService {
	public int newIndent(){
		return 0;
	}
}
